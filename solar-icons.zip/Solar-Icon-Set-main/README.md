<img src="src/banner.png">

# Solar Icon Set - free giant icon pack as big as Solar System!


## What is this?

Solar is a large icon library consisting of pictograms that are modern in style. Their peculiarity lies in the fact that they have corner smoothing raised up to 100%. And because of this interesting feature the icons look quite unique and catchy. All icons are made inside of Figma using special grid which makes them perfectly balanced and adjusted in relation to each other. 

## What's inside?

✨ 7479 fully customisable sexy icons

✨ 37 popular categories

✨ 6 icon styles: Linear, Line Duotone, Bold, Bold Duotone, Broken, Outline

✨ Icon Grid with variations 

✨ Free premium content

✨ Much of love from 480 Design and from creator of those icons! 

---

We would absolutely love you using this pack in Your projects! Share these cool icons with friends or colleagues, drop a like, leave comments down below and follow is for more cool freebie stuff! ❤️‍🔥

## We are also in the
* [Figma](https://www.figma.com/@480design)
* [Telegram](https://t.me/Design480)

## Contact author
t.me/tierohnenation 

